public class Language {
    int ID;
    String code;
    String name;
}
