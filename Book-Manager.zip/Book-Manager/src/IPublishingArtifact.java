public interface IPublishingArtifact {
    public String publish();
}
