public class Countries {
    int ID;
    String countryCode;
}
