public class Author {
    int ID;
    String firstName;
    String lastName;
}
